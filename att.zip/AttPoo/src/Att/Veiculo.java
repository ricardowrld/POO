package Att;

public class Veiculo {
	public int velocidade;
    public boolean status;
	
	
	public void ligar() {
		status = true;
	}
	
	public void desligar() {
		status = false;
	}
	
	public String mostrarStatus() {
	    String stts = String.valueOf(status); 
		return stts;
	}
	
	public static void acelerar() {
		
	}
}
